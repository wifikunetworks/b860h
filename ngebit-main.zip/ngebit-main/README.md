# Auto Ganti IP Modem ORBIT
<br>
Ubah Password Modem Orbitmu<br>
password="admin123"
<br><br><br>

Run Install this:
```
bash -c "$(wget -qO - 'https://raw.githubusercontent.com/aryobrokolly/ngebit/master/install.sh')"
```

If using **Conn Monitor** Install this script:
```
rm -f /usr/bin/lite_watchdog.sh && wget -O /usr/bin/lite_watchdog.sh https://raw.githubusercontent.com/aryobrokolly/scrvp/main/log/lite_watchdog.sh && chmod +x /usr/bin/lite_watchdog.sh
```
